from setuptools import setup

setup(
    name='pycanvas',
    version='0.1.1',
    description='API wrapper for the Canvas LMS',
    url='https://clu.cdl.ucf.edu/techrangers/pycanvas/',
    author='Techrangers (University of Central Florida)',
    author_email='pycanvas@ucf.edu',
    license='Some cool UCF license',
    packages=['pycanvas'],
    install_requires=['requests'],
    zip_safe=False
)
