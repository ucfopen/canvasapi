# -*- coding: utf-8 -*-

from canvas import Canvas

__all__ = ["Canvas"]

__version__ = '0.3.0'
